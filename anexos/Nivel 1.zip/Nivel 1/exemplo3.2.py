import pygame
from pygame.locals import *

class Jogo:

    def __init__(self, file_name):
        pygame.init()        
        self.screen = pygame.display.set_mode((640,480),0,32)        
        self.surface = pygame.image.load(file_name).convert()
        self.background = pygame.image.load("IMG/background.png").convert()
        self.surface.set_colorkey((0,255,0))
        self.clock = pygame.time.Clock();        
        self.x = 0
        self.y = 0
        
    def key_pressed(self, key):

        if key == K_DOWN:
            self.y += 10
        if key == K_UP:
            self.y -= 10
        if key == K_LEFT:
            self.x -= 10
        if key == K_RIGHT:
            self.x += 10        

    def run(self):     
        while True:
             self.clock.tick(40)
             for event in pygame.event.get():
                 if event.type == QUIT:
                     return
                 if event.type == KEYDOWN:
                     self.key_pressed(event.key)
             self.screen.blit(self.background,(0,0))
             self.screen.blit(self.surface, (self.x, self.y))             
             pygame.display.flip()
        



game = Jogo("IMG/nave1.png")
game.run()

