import pygame
from pygame.locals import *

class Jogo:

    def __init__(self, file_name):
        pygame.init()        
        self.screen = pygame.display.set_mode((640,480),0,32)        
        self.surface = pygame.image.load(file_name).convert()
        self.background = pygame.image.load("IMG/background.png").convert()
        self.surface.set_colorkey((0,255,0))
        self.clock = pygame.time.Clock();

    def run(self):
        x = 0 - self.surface.get_width()
        while True:
             self.clock.tick(40)
             for event in pygame.event.get():
                 if event.type == QUIT:
                    return
             self.screen.blit(self.background,(0,0))
             self.screen.blit(self.surface, (x,0))             
             x += 10
             if x > self.screen.get_width() + self.surface.get_width():
                x = 0 - self.surface.get_width()            
             pygame.display.flip()
        



game = Jogo("IMG/nave1.png")
game.run()
