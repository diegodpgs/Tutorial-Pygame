import pygame
from pygame.locals import *

class Jogo:

    def __init__(self, file_name):
        pygame.init()
        self.screen = pygame.display.set_mode((640,480),0,32)           
        self.surface = pygame.image.load(file_name).convert()
        self.background = pygame.image.load("IMG/background.png").convert()
    def run(self):
        while True:

             self.screen.blit(self.background,(0,0))
             self.screen.blit(self.surface, (0,0))
             pygame.display.flip()

game = Jogo("IMG/nave1.png")
game.run()
